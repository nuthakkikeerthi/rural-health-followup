# Rural Health Follow-up Assurance Dataset
Competition Dataset for Non-Communicable Diseases (Hypertension & Diabetes) in Primary Care Catchments.
Contains 19 authoritative files including patient 360 reference, screening, teleconsultations, dispensing, lab tests, outreach history, and submission templates.
